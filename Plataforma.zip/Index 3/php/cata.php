<?php
$servername = "tu_servidor";
$username = "tu_usuario";
$password = "tu_contraseña";
$dbname = "LibreriaPacifico";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Procesar el formulario para agregar un producto
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["agregar"])) {
    $nombre_producto = $_POST["nombre_producto"];
    $precio_producto = $_POST["precio_producto"];
    $categoria = $_POST["Categoria"];
    $marca = $_POST["Marca"];
    $cantidad = $_POST["cantidad"];
    $descripcion_producto = $_POST["descripcion_producto"];

    $sql = "INSERT INTO Productos (nombre_producto, precio_producto, categoria, marca, cantidad, descripcion_producto)
            VALUES ('$nombre_producto', '$precio_producto', '$categoria', '$marca', '$cantidad', '$descripcion_producto')";

    if ($conn->query($sql) === TRUE) {
        echo "Producto agregado correctamente";
    } else {
        echo "Error al agregar el producto: " . $conn->error;
    }
}

// Procesar el formulario para modificar un producto
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["modificar"])) {
    // ... código para modificar un producto ...
}

// Procesar el formulario para eliminar un producto
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["eliminar"])) {
    // ... código para eliminar un producto ...
}

// Consultar todos los productos
$sql = "SELECT * FROM Productos";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Nombre: " . $row["nombre_producto"] . " - Precio: " . $row["precio_producto"] . "<br>";
        // ... mostrar otros detalles del producto ...
    }
} else {
    echo "No hay productos";
}

// Cerrar la conexión
$conn->close();
?>
