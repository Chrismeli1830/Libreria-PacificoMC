<?php
// Configuración de la base de datos
$servername = "nombre_del_servidor";
$username = "nombre_de_usuario";
$password = "contraseña";
$dbname = "nombre_de_la_base_de_datos";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Función para agregar un registro
function agregarRegistro($nombre, $direccion, $telefono) {
    global $conn;
    $sql = "INSERT INTO tu_tabla (nombre_editorial, direccion_editorial, telefono_editorial)
            VALUES ('$nombre', '$direccion', '$telefono')";

    if ($conn->query($sql) === TRUE) {
        echo "Registro agregado correctamente";
    } else {
        echo "Error al agregar el registro: " . $conn->error;
    }
}

// Función para editar un registro
function editarRegistro($id, $nombre, $direccion, $telefono) {
    global $conn;
    $sql = "UPDATE tu_tabla
            SET nombre_editorial='$nombre', direccion_editorial='$direccion', telefono_editorial='$telefono'
            WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Registro editado correctamente";
    } else {
        echo "Error al editar el registro: " . $conn->error;
    }
}

// Función para eliminar un registro
function eliminarRegistro($id) {
    global $conn;
    $sql = "DELETE FROM tu_tabla WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Registro eliminado correctamente";
    } else {
        echo "Error al eliminar el registro: " . $conn->error;
    }
}

// Función para consultar todos los registros
function consultarRegistros() {
    global $conn;
    $sql = "SELECT * FROM tu_tabla";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "ID: " . $row["id"] . " - Nombre: " . $row["nombre_editorial"] . " - Dirección: " . $row["direccion_editorial"] . " - Teléfono: " . $row["telefono_editorial"] . "<br>";
        }
    } else {
        echo "No hay registros";
    }
}

// Cerrar la conexión
$conn->close();
?>
