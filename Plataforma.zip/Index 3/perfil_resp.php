<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>DULCERIA CLASSIC CANDY</title>
    <link rel="stylesheet" href="../est/opcion.css">
    <link rel="stylesheet" href="../est/iniciarsesion.css">
</head>
<body background="imagenes index/background/dulcesLogin.jpeg">></body>
        <!--Encabezado de la pagima--> 
        <header>
            <a href="index.html">
            <img src="img/LOGO.jpeg" alt="CC" >
            <div id="us" >
                <img id="usua" src="imagenes index/max.jpeg" alt="fotousuario">
                 <td>Bienvenido, Maximiliano</td>
                </div>
        </a>
            <h1>CLASSIC CANDY</h1>

               
            <nav>
                <a id="boton-bonito" href="index.html">Inicio</a>
                <a id="boton-bonito" href="consulta1.html">Productos</a>
                <a id="boton-bonito" href="#">Ofertas</a>
                <a id="boton-bonito" href="#">Ayuda</a>
                <a id="boton-bonito" href="#">Registrarse</a>
                <a id="boton-bonito" href="iniciar_sesion.html">Cerrar Sesión</a>
            </nav>
        </header> 
        <div>
            
        <h3>Administra tus productos y Usuarios</h3>
         <div class="contenedor-imagenes">
            <div class="imagen">
                <img src="img/adminproducto.jpg">
                <a href="mantener_producto.php">
                <div class="overlay">
                    <h2>Agrega Producto</h2>
                </div>
            </div>
        </a>
            <div class="imagen">
                <img src="img/adminusua.jpg" alt="Paletas">
                <a href="mantener_usuario.php">
                <div class="overlay">
                    <h2>Administra empleado</h2>
                </div>
            </div>
            </div>
        </a>

        </body>
        <footer class="footer">
            <div class="container">
                <div class="footer-row">
                    <div class ="footer-links">
                        <h4>Compañia</h4> 
                        <ul>
                            <li><a>Acerca de Nosotros</a></li>
                        </ul>
                    </div>
                    <div class ="footer-links">
                        <h4>Ubicación</h4> 
                        <ul>
                            <li><a>Av. Pantitlan #246 Col. Raul Romero</a></li>
                            <li><i>Teléfono 5557656030</i></li>
                            <li><i>© CyberPunk</i></li>
                        </ul>
                    </div>
                    <div class ="footer-links">
                        <h4>Siguenos</h4> 
                        <div class="social-link">
                            <a href="https://es-la.facebook.com/"><img src = "imagenes index/icons/facebook.png" height="30px" width="30px"/></a>
                            <a href="https://www.instagram.com/"><img src = "imagenes index/icons/instagram.jpeg" height="30px" width="30px"/></a>
                            <a href="https://twitter.com/?lang=es"><img src = "imagenes index/icons/twitter.png" height="28px" width="28px"/></a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        
        </html>