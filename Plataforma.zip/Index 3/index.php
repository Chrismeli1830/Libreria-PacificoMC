<?php
include("../header.php");
?>
       <title>Librería Pacifico</title>
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="slick.css">
</head>
<body>

	<!-- Navigation -->
	<nav class="site-navigation">
		<div class="site-navigation-inner site-container">
			<img src="img/libreria.png" alt="site logo" width=90 height=70>
			<div class="main-navigation">
				<ul class="main-navigation__ul">
					<li><a href="index.html">Inicio</a></li>
					<li><a href="consulta1.html">Productos</a></li>
					<li><a href="acerca.html">Acerca</a></li>
					<li><a href="iniciar_sesion.html">Inicio de sesion</a></li>
					<li><a href="registrar_sesion.html">Registrar cuenta</a></li>
				</ul>
			</div>
			<div id="myBtn" class="burger-container" onclick="myFunction(this)">
				<div class="bar1"></div>
				<div class="bar2"></div>
				<div class="bar3"></div>
			</div>
			<script>
				function myFunction(x) {
					x.classList.toggle("change");
				}
			</script>

		</div>
	</nav>
	<!-- Navigation end -->

	<!-- Top banner -->
	<section class="fh5co-top-banner">
		<div class="top-banner__inner site-container">
			<div class="top-banner__image">
				<img src="img/LVSI.jpeg" alt="author image">
			</div>
			<div class="top-banner__text">
				<div class="top-banner__text-up">
					<span class="brand-span">Hola nosotros somos Librería Pacifico</span>
					<h2 class="top-banner__h2">Quienes te haran</h2>
				</div>
				<div class="top-banner__text-down">
					<h2 class="top-banner__h2">Ir a otro mundo</h2>
					<span class="brand-span">Con nuestros grandes titulos como:</span>
				</div>
				<p>Las ventajas de ser invisible: La cual es una novela muy exitosa que ha tenido impacto
					en muchas personas al leerlo "Te recomendamos este gran titulo"
				</p>
				<a href="#" class="brand-button">Saber mas> </a>
			</div>
		</div>
	</section>
	<!-- Top banner end -->

	<!-- About me -->
	<section class="fh5co-about-me">
		<div class="about-me-inner site-container">
			<article class="portfolio-wrapper">
				<div class="portfolio__img">
					<img src="img/nuevos.png" class="about-me__profile" alt="about me profile picture">
				</div>
				<div class="portfolio__bottom">
					<div class="portfolio__name">
						<span>L</span>
						<h2 class="universal-h2">o mas nuevo</h2>
					</div>
					<p>Los mejores titulos nunca antes vistos llagan a Mexico para cautivarte</p>
				</div>
			</article>
			<div class="about-me__text">
				<div class="about-me-slider">
					<div class="about-me-single-slide">
						<h2 class="universal-h2 universal-h2-bckg">"Cielo por tu luz"</h2>
						<p><span>L</span> a novela “Cielo por tu luz” nos sumerge en una historia de amor juvenil llena de secretos y valentía. Alex y Luz, dos chicos que crecieron enamorados, finalmente se atreven a quererse, pero el destino los separa. En su último año de preparatoria, Luz regresa a la vida de Alex, quien sigue amándola 
							a pesar de haberla perdido años atrás. Sin embargo, Luz ha vuelto con misterios y cuando Alex logra enamorarla nuevamente, ella desaparece una vez más. Alex comprende que el verdadero amor solo llega una vez en la vida y decide desaparecer para recuperar el suyo, cueste lo que cueste. “Cielo por tu luz” es la novela debut de Emiliano Campuzano, 
							una obra divertida, trágica y llena de sorpresas que refleja las locuras del amor juvenil y la valentía ante lo inesperado</p>
						<h4>Escrito por:</h4>
						<p class="p-white"> Emiliano Campuzano</p>
					</div>
					<div class="about-me-single-slide">
						<h2 class="universal-h2 universal-h2-bckg">"Exodo"</h2>
						<p><span>E</span> ste libro nos presenta un mundo donde los vampiros, lobos y seres mágicos existen más allá de los cuentos de hadas. La protagonista, Cecelia Horner, descubre que está rodeada de peligro, amor y secretos mientras se adentra en la organización secreta de los Ravenhood, justicieros con rostros de porcelana perlada y corazones oscuros. El odio y el amor se entrelazan en esta historia llena de misterio y pasión.</p>
						<h4>Escritor por:</h4>
						<p class="p-white">Anissa B. Damon</p>
					</div>
				</div>
			</div>
		</div>
		<div class="about-me-bckg"></div>
	</section>
	<!-- About me end -->

	<section class="fh5co-books">
		<div class="site-container">
			<h2 class="universal-h2 universal-h2-bckg">Nuevos libros</h2>
			<div class="books">
				<div class="single-book">
					<a href="#" class="single-book__img">
						<img src="img/Xilo.webp" alt="single book ">
						<div class="single-book_download">
							<img src="img/download.svg" alt="book image">
						</div>
					</a>
					<h4 class="single-book__title">Xilo el naugrafo</h4>
					<span class="single-book__price">$99.00</span>
					<!-- star rating -->
					<div class="rating">
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
					</div>
					<!-- star rating end -->
				</div>
				<div class="single-book">
					<a href="#" class="single-book__img">
						<img src="img/ojos de plata.webp" alt="single book and cd">
						<div class="single-book_download">
						</div>
					</a>
					<h4 class="single-book__title">Ojos de plata</h4>
					<span class="single-book__price">$122.00</span>
					<!-- star rating -->
					<div class="rating">
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
					</div>
					<!-- star rating end -->
				</div>
				<div class="single-book">
					<a href="#" class="single-book__img">
						<img src="img/Zombie.webp" alt="single book and cd">
						<div class="single-book_download">
						</div>
					</a>
					<h4 class="single-book__title">Zombis</h4>
					<span class="single-book__price">$155.00</span>
				<!-- star rating -->
				<div class="rating">
					<span>&#9734;</span>
					<span>&#9734;</span>
					<span>&#9734;</span>
					<span>&#9734;</span>
					<span>&#9734;</span>
				</div>
				<!-- star rating end -->
		
			<div class="books-brand-button">
				<a href="productos.html" class="brand-button">View more</a>
			</div>
		</div>
	</section>

	<section class="fh5co-books">
		<div class="site-container">
			<div class="books">
				<div class="single-book">
					<a href="#" class="single-book__img">
						<img src="img/l-pijama.jpg" alt="single book ">
						<div class="single-book_download">
							<img src="img/download.svg" alt="book image">
						</div>
					</a>
					<h4 class="single-book__title">El niño con el pijama de rayas</h4>
					<span class="single-book__price">$299.00</span>
					<!-- star rating -->
					<div class="rating">
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
					</div>
					<!-- star rating end -->
				</div>
				<div class="single-book">
					<a href="#" class="single-book__img">
						<img src="img/principito.jpg" alt="single book and cd">
						<div class="single-book_download">
						</div>
					</a>
					<h4 class="single-book__title">El principito</h4>
					<span class="single-book__price">$122.00</span>
					<!-- star rating -->
					<div class="rating">
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
					</div>
					<!-- star rating end -->
				</div>
				<div class="single-book">
					<a href="#" class="single-book__img">
						<img src="img/monstruo_colores.jpg" alt="single book and cd">
						<div class="single-book_download">
						</div>
					</a>
					<h4 class="single-book__title">Monstruo de colores</h4>
					<span class="single-book__price">$120.00</span>
				<!-- star rating -->
				<div class="rating">
					<span>&#9734;</span>
					<span>&#9734;</span>
					<span>&#9734;</span>
					<span>&#9734;</span>
					<span>&#9734;</span>
				</div>
				<!-- star rating end -->
		
			<div class="books-brand-button">
				<a href="productos.html" class="brand-button">View more</a>
			</div>
		</div>
	</section>

	<section class="fh5co-books">
		<div class="site-container">
			<div class="books">
				<div class="single-book">
					<a href="#" class="single-book__img">
						<img src="img/oceano.jpg" alt="single book ">
						<div class="single-book_download">
							<img src="img/download.svg" alt="book image">
						</div>
					</a>
					<h4 class="single-book__title">Despues del oceano</h4>
					<span class="single-book__price">$230.00</span>
					<!-- star rating -->
					<div class="rating">
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
					</div>
					<!-- star rating end -->
				</div>
				<div class="single-book">
					<a href="#" class="single-book__img">
						<img src="img/L-llamas.jpg" alt="single book and cd">
						<div class="single-book_download">
						</div>
					</a>
					<h4 class="single-book__title">En llamas</h4>
					<span class="single-book__price">$250.00</span>
					<!-- star rating -->
					<div class="rating">
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
						<span>&#9734;</span>
					</div>
					<!-- star rating end -->
				</div>
				
				<div class="single-book">
					<a href="#" class="single-book__img">
						<img src="img/p-poesia.jpg" alt="single book and cd">
						<div class="single-book_download">
						</div>
					</a>
					<h4 class="single-book__title">Ni de aquí ni de allá</h4>
					<span class="single-book__price">$418.00</span>
				<!-- star rating -->
				<div class="rating">
					<span>&#9734;</span>
					<span>&#9734;</span>
					<span>&#9734;</span>
					<span>&#9734;</span>
					<span>&#9734;</span>
				</div>
				<!-- star rating end -->
		
			<div class="books-brand-button">
				<a href="productos.html" class="brand-button">View more</a>
			</div>
		</div>
	</section>

	<!-- Counter -->
	<div class="fh5co-counter counters">
		<div class="counter-inner site-container">
			<div class="single-count">
				<span class="count" data-count="50">0</span>
				<div class="single-count__text">
					<img src="img/counter-1.png" alt="counter icon">
					<p>Books</p>
				</div>
			</div>
			<div class="single-count">
				<span class="count" data-count="600">0</span>
				<div class="single-count__text">
					<img src="img/counter-2.png" alt="counter icon">
					<p>Pages</p>
				</div>
			</div>
			<div class="single-count">
				<span class="count" data-count="2000">0</span>
				<div class="single-count__text">
					<img src="img/counter-3.png" alt="counter icon">
					<p>Sales</p>
				</div>
			</div>
			<div class="single-count">
				<span class="count" data-count="125">0</span>
				<div class="single-count__text">
					<img src="img/counter-4.png" alt="counter icon">
					<p>Awards</p>
				</div>
			</div>
		</div>
	</div>
	<!-- Counter -->

	<!-- Blog -->
	<section class="fh5co-blog">
		<div class="site-container">
			<h2 class="universal-h2 universal-h2-bckg">Los mas vendido</h2>
			<div class="blog-slider blog-inner">
				<div class="single-blog">
					<div class="single-blog__img">
						<img src="img/pan.webp" alt="blog image">
					</div>
					<div class="single-blog__text">
						<h4>Pan de muerto</h4>
						<span>Publicado 1 de enero de 2008</span>
						<span>Editoria: Porrua</span>
						<p>En esta obra, Ana María explora el deseo y la fascinación del ser humano ante la muerte. La historia nos sumerge en un singular encuentro entre dos personajes: un maquillista de
							 muertos con extrañas pasiones y una difunta demasiado viva. A través de esta trama erótica y burlesca, se recrea la actitud 
							 festiva y de veneración del mexicano frente a la muerte, así como el machismo que se esconde detrás de esta concepción, donde la muerte es mujer.</p>
					</div>
				</div>
				<div class="single-blog">
					<div class="single-blog__img">
						<img src="img/Laspuertas.webp" alt="blog image">
					</div>
					<div class="single-blog__text">
						<h4>Las puertas del infierno</h4>
						<span>Publicado en 2010</span>
						<span>Editorial: Oceano</span>
						<p>Esta novela nos transporta a Berlín, 1938. Meses antes de la invasión de Checoslovaquia y Polonia por el ejército de Hitler, Bruno Meyer, un brillante estudiante de Derecho, se ve obligado a abandonar
							 las aulas universitarias tras el asesinato de su padre. En busca de los medios para mantener a su familia, Bruno ingresa a la Kripo, la policía criminal de Alemania. En la corrupta institución se 
							 enfrentará al laberinto de infamias, engaños y traiciones en que se ha convertido el Tercer Reich: un lodazal de muerte, venganza, avaricia y ambición sin límites.</p>
					</div>
				</div>
				<div class="single-blog">
					<div class="single-blog__img">
						<img src="img/campo.webp" alt="blog image">
					</div>
					<div class="single-blog__text">
						<h4>Campo general</h4>
						<span>Publicado en 2001</span>
						<span>Editorial:  Fondo de Cultura Económica (FCE).</span>
						<p>“Campo general” es más que el retrato fascinante de la indómita región del gran sertón brasileño; Guimarães Rosa también ofrece en esta novela un paisaje literario profundo que nos permite 
							comprender la relación entre las pasiones humanas y la naturaleza.
							Por las andanzas cotidianas de Miguelín y su familia en el Mutún, nos adentramos en la experiencia de un niño que construye su identidad, que vive entre la esperanza de conocer nuevas tierras
							 y el sufrimiento que provoca enfrentarse a un ambiente adverso</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Blog end -->

	<!-- Social -->
	<section class="fh5co-social">
		<div class="site-container">
			<div class="social">
				<h5></h5>
				<div class="social-icons">
					<a href="#" target="_blank"><img src="img/social-twitter.png" alt="social icon"></a>
					<a href="#" target="_blank"><img src="img/social-pinterest.png" alt="social icon"></a>
					<a href="#" target="_blank"><img src="img/social-youtube.png" alt="social icon"></a>
				</div>
				<h5></h5>
			</div>
		</div>
	</section>
	<!-- Social -->

	<!-- Footer -->
	<footer class="site-footer">
		<div class="site-container">
			<div class="footer-inner">
				<div class="footer-info">
					<div class="footer-info__left">
						<img src="img/footer-img.jpg" alt="about me image">
						<p>Derechos reservados</p>
					</div>
					<div class="footer-info__right">
						<h5>Contactanos</h5>
						<p class="footer-phone">Telefono: +525616221825</p>
						<p></p>
						<div class="social-icons">
							<a href="https://twitter.com/x" target="_blank"><img src="img/social-twitter.png" alt="social icon"></a>
							<a href="https://www.pinterest.com.mx/" target="_blank"><img src="img/social-pinterest.png" alt="social icon"></a>
							<a href="https://www.youtube.com/?gl=ES" target="_blank"><img src="img/social-youtube.png" alt="social icon"></a>
						</div>
					</div>
				</div>
				<div class="footer-contact-form">
					<h5>Contact Form</h5>
					<form class="contact-form">
						<div class="contact-form__input">
							<input type="text" name="name" placeholder="Nombre">
							<input type="email" name="email" placeholder="Email">
						</div>
						<textarea></textarea>
						<input type="submit" name="submit" value="Enviar" class="submit-button">
					</form>
				</div>
			</div>
		</div>
		<div class="footer-bottom">
			<div class="site-container footer-bottom-inner">
				<p>© 2023 MC |   All rights Reserved.</p>
				<div class="footer-bottom__img">
					<img src="img/footer-mastercard.png" alt="footer image">
					<img src="img/footer-paypal.png" alt="footer image">
					<img src="img/footer-visa.png" alt="footer image">
					<img src="img/footer-fedex.png" alt="footer image">
					<img src="img/footer-dhl.png" alt="footer image">
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer end -->

	<!-- Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/main.js"></script>

</body>
</html>